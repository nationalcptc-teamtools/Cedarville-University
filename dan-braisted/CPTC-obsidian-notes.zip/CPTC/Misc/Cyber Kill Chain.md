#### Reconnaissance
Gather information about target
Passive: WHOIS, DNS, OSINT
Active: port scanning, vulnerability scanning, physical reconnaissance
#### Weaponization
Create tailored payload
Ready-made or from scratch
#### Delivery
Transmit payload to target environment
Includes social engineering (phishing, etc.)
#### Exploitation
Take advantage of vulnerability
Software vulnerability, weak password, misconfiguration, etc.
#### Installation
Establish persistence
Cron jobs/scheduled tasks, malware, backdoors, web shells, etc.
#### Command and Control
Establish covert communication channel
Can use standard protocols to blend in with legitimate traffic
Encryption, DNS tunneling, legitimate cloud services
Doman registration algorithms, fast flux
#### Actions on Objectives
Carry out original goals
Ransomware, data exfiltration, lateral movement