## Open Source Security Testing Methodology Manual (OSSTMM)

Focuses on quantifiable metrics

5 security channels:
- Human Security (HUMSEC)
- Physical Security (PHYSSEC)
- Wireless Communications (SPECSEC)
- Telecommunications (COMSEC)
- Data Networks (DATASEC)

Risk Assessment Values (RAVs)
Balance between attack surface and controls protecting it
Positive indicates risk, near-zero means controls well-matched to exposure

4 phases:
- Induction: Enumeration and verification
- Interaction: Qualification and quantification
- Inquiry: Privilege escalation and verification escalation
- Intervention: Quarantine, audit, and enticement

Security Test Audit Report (STAR)

## Web Security Testing Guide (WSTG)

Created by Open Web Application Security Project (OWASP)
12 categories spanning full attack surface of modern web applications
Numbered test cases for each category
Risk-based approach, prioritizing vulnerabilities by exploitability and impact

Tests across 5 phases of the software development life cycle:
- Before development begins
- During definition and design
- During development
- During deployment
- During maintenance and operations

Exhaustive, practical coverage

## NIST Special Publication 800-115

Not just pentesting; more general security testing and assessment techniques

3 core objectives:
- Identify vulnerabilities
- Validate security controls
- Assess exploitability

3 testing phases:
- Planning
- Execution
	- Review techniques
	- Target identification and analysis
	- Target vulnerability validation
	- Penetration testing
- Post-testing

Flexibility, institutional credibility

## Penetration Testing Execution Standard (PTES)

Mirrors actual penetration testing workflow

7 phases:
- Pre-engagement interactions
- Intelligence gathering
- Threat modeling
- Vulnerability analysis
- Exploitation
- Post-exploitation
- Reporting

Practical, end-to-end structure
Not formally updated in several years

## Information Systems Security Assessment Framework (ISSAF)

Developed by Open Information Systems Security Group (OISSG)
Latest version published around 2006; no longer actively maintained
Mirrors kill-chain logic

3 phases:
- Planning and preparation
- Assessment
- Reporting and cleanup

9-step assessment model (phase 2):
- Information gathering
- Network mapping
- Vulnerability identification
- Penetration
- Gaining access and privilege escalation
- Enumerating further
- Compromise remote users/sites (lateral movement)
- Maintaining access
- Covering tracks

## Adversarial Tactics, Techniques, and Common Knowledge (MITRE ATT&CK)

Not a traditional framework; knowledge base of adversary behavior
Organized as a matrix
Columns represent tactics, rows list techniques
Standardized language/universal translator for describing findings
Annotate other reports with ATT&CK technique IDs

## Other Specialized Frameworks

WASC Threat Classification: web apps, influential but superseded by OWASP WSTG
CSA Cloud Controls Matrix: compliance tool for cloud computing environments
OWASP Mobile Application Security Testing Guide: mobile counterpart to WSTG
PCI DSS Penetration Testing Guidelines: regulatory mandates for payment card industry
CBEST Framework: UK financial institutions, closely integrates threat intelligence