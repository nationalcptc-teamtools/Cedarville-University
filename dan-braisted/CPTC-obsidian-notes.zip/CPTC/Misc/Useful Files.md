## After initial access, may want to look for these

| File                        | Purpose                                   |
| --------------------------- | ----------------------------------------- |
| /etc/issue                  | Message to be printed before login prompt |
| /etc/profile                | System-wide default variables             |
| /etc/passwd                 | Registered users                          |
| /etc/shadow                 | Password hashes                           |
| /proc/version               | Linux kernel version                      |
| /{user}/.bash_history       | Command history                           |
| /{user}/.ssh/id_rsa         | Private SSH keys                          |
| /var/log/dmessage           | Global system messages                    |
| /var/mail/{user}            | Emails                                    |
| /var/log/apache2/access.log | Apache web requests                       |
| C:\boot.ini                 | BIOS boot options on Windows              |
