## Types of Security Groups

Enterprise Admins: admin privileges over all domains
Domain Admins: admin privileges over domain
Server Operators: admin privileges over DCs
Backup Operators: access to all files regardless of permissions
Account Operators: create and modify accounts
Domain Users: all user accounts
Domain Computers: all computer accounts
Domain Controllers: all DCs