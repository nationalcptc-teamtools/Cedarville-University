#### Week 1
**5/4/26**
Time: 14:51-15:56 (1 hr 5 min)
Content: THM - JPT 3 [[Web Hacking]]
Progress: Rooms 2-4 (Content Discovery, Subdomain Enumeration, Authentication Bypass)
Notes: Redoing modules as a refresher and for comprehensive notes

**5/5/26**
Time: 14:00-15:19 (1 hr 19 min)
Content: THM - JPT 3 [[Web Hacking]]
Progress: Rooms 5-7 (IDOR, File Inclusion, Intro to SSRF)

**5/6/26**
Time: 14:54-16:07 (1 hr 13 min)
Content: THM - JPT 3 [[Web Hacking]]
Progress: Rooms 8, 10 (Intro to Cross-site Scripting, Command Injection)
Notes: Skipped room 9 (race conditions) since it recommended Burp Suite familiarity as a prerequisite; will revisit after completing section 4

**5/7/26**
Time: 15:00-16:32 (1 hr 32 min)
Content: THM - JPT 4 [[Burp Suite]]
Progress: Room 1 (Basics)

**5/8/26**
Time: 14:28-16:08 (1 hr 40 min)
Content: THM - JPT 4 [[Burp Suite]]
Progress: Rooms 2-3 (Repeater, Intruder)

**Total:**
6 hr 49 min

#### Week 2
**5/11/26**
Time: 13:48-15:02 (1 hr 14 min)
Content: THM - JPT 4 [[Burp Suite]]
Progress: Room 4 (Other Modules)

**5/12/26**
Time: 16:03-16:31 (28 min)
Content: THM - JPT 4 [[Burp Suite]]
Progress: Room 5 (Extensions)

**5/13/26**
Time: 13:50-15:52 (2 hr 2 min)
Content: THM - JPT 3 [[Web Hacking]]
Progress: Rooms 9, 11 (Race Conditions, SQL Injection)

**5/14/26**
Time: 13:17-14:21 (1 hr 4 min)
Content: THM - JPT 5 Network Security
Progress: Room 3 ([[Nmap]] Live Host Discovery)
Notes: Rooms 1-2 and 7-8 already completed

**5/15/26**
Time: 14:33-16:15 (1 hr 42 min)
Content: THM - JPT 5 Network Security
Progress: Rooms 4-5 ([[Nmap]] Basic Port Scans, [[Nmap]] Advanced Port Scans)

**Total:**
6 hr 30 min

#### Week 3
**5/18/26**
Time: 15:54-17:15 (1 hr 21 min)
Content: THM - JPT 5 Network Security
Progress: Rooms 6, 9 ([[Nmap]] Post Port Scans, Net Sec Challenge)

**5/19/26**
Time: 14:35-15:50 (1 hr 15 min)
Content: THM - JPT 6 [[Vulnerability Research]]
Progress: Rooms 1-3 (Vulnerabilities 101, Exploit Vulnerabilities, Vulnerability Capstone)

**5/20/26**
Time: 14:20-15:40 (1 hr 20 min)
Content: THM - JPT 7 [[Metasploit]], JPT 8 [[Privilege Escalation]]
Progress: Room 3 (Meterpreter), Room 2 (Linux Privilege Escalation) Tasks 1-4
Notes: Room 1 of JPT 8 already complete

==**THM Reorganized Here**==

**5/21/26**
Time: 14:03-15:11 (1 hr 8 min)
Content: THM - [[Privilege Escalation]]
Progress: Linux Privilege Escalation Tasks 5-8

**5/22/26**
Time: 13:55-15:20 (1 hr 25 min)
Content: THM - [[Privilege Escalation]]
Progress: Linux Privilege Escalation Tasks 9-12

**Total:**
6 hr 29 min

#### Week 4
**5/27/26**
Time: 15:45-16:50 (1 hr 5 min)
Content: THM - JPT 1 Start, JPT 9 [[Vulnerability Knowledge]]
Progress: JPT 1 Room 3 (Search Skills), JPT 9 Rooms 1-2 (Understanding Vulnerability Databases, Vulnerability Scanning Tools)

**5/28/26**
Time: 13:54-14:53 (59 min)
Content: THM - JPT 9 [[Vulnerability Knowledge]]
Progress: Room 3 (Basic Vulnerability Identification Techniques)

**5/29/26**
Time: 14:04-15:06 (1 hr 2 min)
Content: THM - JPT 9 [[Vulnerability Knowledge]]
Progress: Rooms 4-5 (Tomcat, n8n)

**Total:**
3 hr 6 min

#### Week 5
**6/1/26**
Time: 20:07-20:42 (35 min)
Content: THM - JPT 9 [[Vulnerability Knowledge]]
Progress: Room 6 (AD BadSuccessor)

**6/2/26**
Time: 18:40-19:35 (55 min)
Content: THM - JPT 2 Penetration Testing Foundations
Progress: Room 1 (Guided Pentest Web)

**6/4/26**
Time: 21:02-21:27 (25 min)
Content: THM - JPT 2 Penetration Testing Foundations
Progress: Room 2 (Guided Pentest Infrastructure)

**6/6/26**
Time: 10:24-11:19 (55 min)
Content: THM - JPT 2 Penetration Testing Foundations
Progress: Rooms 3-4 (Dive Into Pentesting, [[Cyber Kill Chain]])

**Total:**
2 hr 50 min

#### Week 6
**6/10/26**
Time: 19:56-21:09 (1 hr 13 min)
Content: THM - JPT 2 Penetration Testing Foundations
Progress: Room 5 (Penetration Testing [[Frameworks]])

**6/12/26**
Meeting day

**6/13/26**
Time: 13:27-14:31 (1 hr 4 min)
Content: THM - JPT 9 [[Vulnerability Knowledge]]
Progress: Rooms 7-8 (Fragnesia, Nginx Rift)

#### Week of June 29
**6/29/26**
Time: 19:48-21:02 (1 hr 14 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 2 (Intro to AD Authentication)

**7/2/26**
Time: 20:17-21:43 (1 hr 26 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 3 (Intro to AD Breaching)

#### Week of July 6
**7/7/26**
Time: 19:10-20:26 (1 hr 14 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 4 (Basic Enumeration)

**7/10/26**
Time: 15:53-16:27, 17:54-18:44 (1 hr 24 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 5 (Authenticated Enumeration)

#### Week of July 13
**7/13/26**
Time: 20:23-21:20 (57 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 6 (Intro to Credential Harvesting)

**7/17/26**
Time: 20:06-21:15 (1 hr 9 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 7 (Intro to AD Lateral Movement)

#### Week of July 27
**7/28/26**
Time: 19:29-20:27 (58 min)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 1 (Active Directory Basics) - Incomplete
Notes: It appears the first room in the module was replaced with a new one
VM was broken (no internet connection) and couldn't finish install script

**8/1/26**
Time: 11:01-12:01 (1 hr)
Content: THM - JPT 14 [[AD Security Testing Basics]]
Progress: Room 1 (Active Directory Basics)

#### Week of August 3
**8/7/2026**
Time: 11:14-12:25 (1 hr 11 min)
Content: THM - JPT 17 [[Pentesting Methodologies and Reporting]]
Progress: Room 1 (Threat Modeling)