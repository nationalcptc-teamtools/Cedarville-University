
## Live Host Discovery
Finding out which systems are currently running

Nmap defaults to ping scan to find live hosts, then port scan of live hosts

#### ARP Discovery
Default for privileged user scanning targets on local network
Only works for targets on same local network as device Nmap is run from
Use `sudo nmap -PR -sn [targets]` to run ARP scan without port scan

#### ICMP Discovery
Use `sudo nmap -PE -sn [targets]` to run ICMP echo request scan without port scan
Use `-PP` for ICMP timestamp requests (Type 13)
Use `-PM` for address mask queries (Type 17)
Some firewalls block ICMP echo, including Windows default host firewall

#### TCP/UDP Discovery
TCP SYN/ACK or RST both indicate host is up
TCP SYN ping with `-PS[port(s)]` option (defaults to 80)
TCP ACK ping with `-PA[port(s)]` option (requires privilege)
UDP packet sent to closed port expects ICMP type 3 response (port unreachable)
UDP ping with `-PU` option

#### Reverse DNS Lookup
Nmap automatically performs reverse DNS lookup on online hosts
Use `-n` to skip lookup
Use `-R` to query for even offline hosts
`--dns-servers [dns server]` option


## Basic Port Scans

#### TCP Connect Scan
Establishes connection with 3-way handshake, then terminates with RST
Run with `-sT`

#### TCP SYN Scan
Doesn't fully establish connection; sends RST after SYN/ACK from server (part 2 of handshake)
Run with `-sS`

#### UDP Scan
Open UDP port will not respond
Closed UDP port will respond with port unreachable error (ICMP type 3)
Run with `-sU`

#### Fine-Tuning
`-p[port(s)]`: specify ports or range
`-p-`: scan all ports
`-T[0-5]`: scan timing from slowest to fastest
`-F`: fast mode (100 most common ports)
`-r`: scan ports consecutively rather than randomly
`--min-rate [num]`, `--max-rate [num]`: control packet rate per second
`--min-parallelism=[num]`, `--max-parallelism=[num]`: number of probes that can be run in parallel
`--source-port`: specify source port


## Advanced Port Scans

#### Null Scan
All 6 flag bits set to 0
No response from open port; RST from closed port
Run with `-sN`

#### FIN Scan
FIN flag set
Same resulting behavior as null scan
Run with `-sF`

#### XMAS Scan
FIN, PSH, and URG flags set simultaneously
Same result as null or FIN scan
Run with `-sX`

#### Maimon Scan
FIN and ACK bits set
Packet dropped by some BSD-derived systems on open ports
Won't work on most modern networks
Run with `-sM`

#### TCP ACK Scan
ACK flag set
Always results in RST packet in response
Useful to discover which ports' responses blocked by firewall
Run with `-sA`

#### Window Scan
ACK scan that examines TCP Window field of returned RST packets
Can reveal open ports on some systems, still generally for firewall rules
Run with `-sW`

#### Custom Scan
Can set custom flag combination in Nmap
Syntax: `--scanflags [flags]`
Example: `--scanflags RSTSYNFIN`

#### Spoofing
Spoof IP with `nmap -S [spoofed IP] [target IP]`
Need to monitor network traffic since response will be sent to fake IP
Will likely require more details: `nmap -e [network interface] -Pn -S [spoofed IP] [machine IP]`
Can spoof MAC address with `--spoof-mac [MAC]`
Only works if attacker and target are on same Ethernet/WiFi

#### Decoys
Similar to spoofing, but real and spoofed requests sent alongside each other
`nmap -D [comma-separated IPs] [target IP]`
Use `ME` for own address
Use `RND` for random address

#### Adjusting Packet Size
Fragment IP data section into multiple packets
`-f` for 8 byte sections
`-ff` for 16 byte sections
Can append data to packets to appear more normal
`--data-length [num]` for number of bytes to append

#### Idle/Zombie Scan
Requires communication with idle system on network
Spoof packets as coming from idle host, then watch for response
Record current IP ID of idle host
Send spoofed packet to target
Check if idle host's ID increments by 1 (no response) or 2 (target responded)
Host must be idle for accurate results
Run with `-sI [idle IP]`

#### Additional Info
`--reason` for details regarding reasoning/conclusion
`-v`, `-vv` for verbose output
`-d`, `-dd` for debugging details (more verbose than `-vv`)


## Post Port Scans

#### Service Detection
Run service detection scan with `-sV`
Uses 3-way handshake (must communicate with service to determine version)
Requires privilege to run
`--version-intensity` with levels from 0 to 9
`--version-light` has intensity 2
`--version-all` has intensity 9

#### OS Detection
Enable with `-O`
Based on comparing signatures with database
Results not always definitive
Affected by virtualization, firewalls, network layers, middleware, etc.
TTL: Linux typically 64, Windows typically 128

#### Traceroute
Can combine traceroute into scan with `--traceroute`
Not identical to `traceroute` command, but similar

#### Nmap Scripting Engine
Lua interpreter to allow scripting
Many preinstalled scripts in `/usr/share/nmap/scripts/`
Many different categories of scripts
`-sC` to run scripts in default category
`--script "[script name]"` or `--script=[category]`
Can use pattern matching with `*` (runs all matching scripts)
Can add custom scripts as well

#### Saving Results
- Normal format: `-oN [file name]`
- Grepable: `-oG [file name]`
- XML: `-oX [file name]`
- All of the above: `-oA [file name]`