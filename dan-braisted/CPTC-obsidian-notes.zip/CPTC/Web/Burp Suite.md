
## Basics

#### Key Features
- Proxy: Enables interception and modification of requests
- Repeater: Allows resending requests
- Intruder: Sprays endpoints with requests (rate limited)
- Decoder: Built-in encoding and decoding
- Comparer: Built-in comparison functionality
- Sequencer: Assesses randomness of tokens

#### Settings
- Global/user settings (affect entire installation)
- Project settings (specific to current project, not saved in Community Edition)

#### Proxy
By default, intercepts outgoing requests but not incoming responses
Can change proxy settings to intercept responses
Match and Replace uses regex to modify requests

#### Connecting
1. Make sure Burp Suite is open
2. Click FoxyProxy button in top right of Firefox
3. Click Burp Suite configuration
4. Enable intercept in Burp Suite Proxy tab

#### Target
- Site Map: Automatically maps web pages into tree structure while browsing
- Issues: List vulnerabilities scanner looks for
- Scope: Control target scope (whitelist or blacklist)
Right-click target from list, click "Add to Scope", select "Yes" when asked about stopping logging of anything out of scope
Add `And URL Is in target scope` to "Intercept Client Requests" section in proxy settings


## Repeater
Can modify captured requests from Proxy or create requests from scratch
Can modify raw request or use the Inspector section of the interface
Send captured request from Proxy to Repeater with `Ctrl + R`

## Intruder
Used for fuzzing, brute-forcing
Send request from Proxy with `Ctrl + I`

#### Positions
Add payloads to specific locations within request
Add, clear, and auto options for payload positions

#### Payloads
Create, assign, and configure payloads
Sets, configuration, and processing sections

#### Attack Types
###### Sniper
Iterates linearly through all payloads at each position
Can have multiple positions, but only 1 will be substituted at a time
Only allows 1 payload set

###### Battering Ram
Places same payload in every position simultaneously
Only allows 1 payload set

###### Pitchfork
Similar to Sniper, but uses 1 payload set per position
Nth items in each list used together (no other combinations)
Stops after shortest list is exhausted

###### Cluster Bomb
1 payload set per position
Tries every combination of list values


## Other Modules

#### Decoder
No pre-assigned shortcut, send data with right click -> Send to Decoder
Can also manually input, copy/paste
Decode or encode data in variety of formats
Smart decode option to automatically and recursively identify encoding format(s) and decode
Hashing available in decoder as well

#### Comparer
No pre-assigned shortcut
Can paste raw data or load from file
Compare data by ASCII words or bytes

#### Sequencer
Evaluate entropy/randomness of tokens
Live Capture: pass request that will generate token, request will be made 1000s of times automatically and the results analyzed
Manual Load: use pre-generated list of token samples

#### Organizer
Store and annotate HTTP requests
Send requests from other modules with `Ctrl + O`
Requests and responses are read-only


## Extensions
Listed order of extensions matters (applied in descending order)
BApp Store for official extensions
Java extensions integrate automatically
Jython Interpreter required for Python-based extensions
Burp Suite provides APIs for extension development
Official documentation available for extension development