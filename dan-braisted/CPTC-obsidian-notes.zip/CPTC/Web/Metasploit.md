
## Meterpreter
Metasploit in-memory payload (not written to disk)
Creates encrypted communication channel
Stealthy, but still detected by major antivirus software

#### Flavors
Many variants of Meterpreter for different platforms and protocols
Some exploits have default payload associated with them

#### Commands
`help` to list commands
`run` to execute script
Some commands same as Linux
`upload`, `download` (files or directories)
Many different categories of commands
Varies between different versions

#### Post-Exploitation
`getuid`: display user (useful for privilege level)
`ps`: list running processes
`migrate [PID]`: let Meterpreter interact with process (e.g., keylogging word processor)
`hashdump`: get SAM hashes on Windows system
`search`: search for files
`shell`: launch regular shell