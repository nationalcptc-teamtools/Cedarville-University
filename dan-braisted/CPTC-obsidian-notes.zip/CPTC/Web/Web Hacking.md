
## Content Discovery
3 types: manual, automated, OSINT

#### Manual
- robots.txt (lists pages search engines shouldn't show)
- favicon (can give away framework if not customized, compare with database)
- sitemap.xml (inverse of robots.txt, lists pages search engines should show)
- HTTP headers (server versions, easily get with curl -v)
- Framework website (builds on previous steps)

#### OSINT
- Google dorking (site: inurl: filetype: intitle:)
- Wappalyzer (identifies frameworks + other tech)
- Wayback Machine
- Github
- S3 buckets (AWS file store, {name}.s3.amazonaws.com)

#### Automated
- Wordlists
- ffuf
- dirb
- gobuster


## Subdomain Enumeration
3 types: brute force, OSINT, virtual host

#### OSINT
- Certificate authorities have public logs of SSL/TLS certificates
- Search engines allow operators such as site:\*.website.com
- Sublist3r is automated Kali tool to search several engines for subdomains

#### Brute Force
- DNS enumeration with automated tools like dnsrecon

#### Virtual Host
- Private subdomains may be accessible using Host HTTP header (brute force with ffuf and wordlist)


## Authentication Bypass

#### Username Enumeration/Password Brute Forcing
Use wordlists for usernames and passwords
Look for error messages indicating valid usernames
Brute force passwords for existing users

#### Logic Flaws
Generic group of possible authentication bypass vectors
Examples include faulty PHP comparisons or GET vs. POST priority issues

#### Cookie Tampering
Cookies may be in plaintext, hashed, or base64 encoded


## IDOR
Insecure Direct Object Reference
Example would be getting page by ID without check if it's ID of current user
ID may be encoded/hashed/unpredictable
If unpredictable, can check with 2 accounts - still IDOR
May be in address bar, AJAX, JS


## File Inclusion
Results from lack of input validation for which files a user is requesting

#### Path/Directory Traversal
Getting files "higher up" in directory structure
Uses ../ in file path

#### Local File Inclusion
Based on PHP include()/require() or its equivalents in other languages
Similar to path traversal, but passed as query string parameter rather than directly in URL
Error messages can reveal valuable info
Append null byte if file extension added later (fixed in PHP 5.3.4 and above)
Can bypass weak filters by appending `./`
Single-pass filter can be tricked with `....//`

#### Remote File Inclusion
Include file hosted on another server
More dangerous, can give attacker RCE


## SSRF
Server-Side Request Forgery

#### Examples
Putting different API URL in GET request
Directory traversal variation
`&x=` to "comment out" remaining path by assigning it to new parameter
Putting malicious URL in place of API to get API key

#### Finding SSRF Vulnerabilities
Full URL used as parameter in address bar
Hidden field in form
Partial URL (for instance, hostname)
File path of URL only

#### Bypassing Defenses
Deny List: alternate localhost addresses, fake DNS records on own subdomain
Allow List: create subdomain on own domain matching allowed pattern
Open Redirect: endpoint on server with automatic redirect, redirect to attacker's server


## XSS

#### Reflected XSS
User-supplied HTTP data included in webpage without validation
Embed malicious code into link sent to user
Can be URL parameters or file path

#### Stored XSS
Payload stored in application (usually database)
Comments, profiles, etc. - user input
Test with manual requests, not just provided forms

#### DOM Based XSS
JS executes directly in browser, client-side code acting on user input
Based on crafted links, attacker-controlled variables
Harder to test for, requires examining source code

#### Blind XSS
Can't directly test payload
Staff contact forms, etc.
Payload must have call back, XSS Hunter Express is popular tool

#### XSS Polyglots
Special strings designed to escape attributes, escape tags, and bypass filters automatically
Example:
```
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */onerror=alert('XSS') )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert('XSS')//>\x3e
```


## Command Injection
Often equivalent with RCE
Look for user input being executed as part of command
Blind command injection (no direct output) vs. verbose command injection (application sends feedback)
Detect blind command injection by causing delay (`ping`, `sleep`) or forcing output with redirection
Detect verbose command injection directly in web application
Common way to test is with `curl` command
Can bypass some filters using hex values


## Race Conditions
Time-of-Check to Time-of-Use vulnerabilities
States between making a request and the request being marked as accepted

#### Exploiting with Burp Suite
[[Burp Suite]]
Create tab group, duplicate tab inside it
Send request group in parallel with Send button drop down menu

#### Detection
Understand how the system behaves under normal conditions
Know what controls are enforced
Try to bypass said controls by exploiting race conditions


## SQL Injection

#### Types of SQLi

**In-Band**: Same method of communication to exploit vulnerability and receive results
- Error-Based: Enumerate database using printed error messages
- Union-Based: Use `SELECT` with `UNION` to extract data from other tables

**Blind**: No feedback to confirm successful queries
- Authentication Bypass: get login query that returns true (such as with `' OR 1=1;--`)
- Boolean-Based: API responds with only true/false indicator (true for any successful query); can brute force with `LIKE` operator (regex) to discover table names, column names, and contents
- Time-Based: Similar to boolean, but instead of a value being returned, a `SLEEP(x)` statement is included in query (will only execute on successful query)

**Out-Of-Band**: Two different communication channels
Usually involves forcing HTTP/DNS requests to an attacker-controlled machine

#### Practical Techniques
`database()` to get database name
`group_concat()` to list results as single comma-separated string (useful when only first result is displayed)
`information_schema` table contains information about all databases and tables
`table_name`, `column_name` are useful fields in `information_schema`'s `tables` and `columns` fields respectively